<!DOCTYPE html>
<html>

<head>
    <title>Playdede - CRUD</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="shortcut icon" href="img/favicon32.png" type="image/x-icon">
    <style>
        body {
            background-color: black;
            color: white;
        }

        form {
            margin-top: 20px;
        }

        form input,
        form textarea {
            display: block;
            margin-bottom: 10px;
        }

        form input[type="submit"] {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <header>
        <h1>CRUD</h1>
    </header>

    <?php
    // Establecer la conexión a la base de datos
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "playdede";

    $connection = mysqli_connect($host, $user, $password, $database);

    // Verificar si la conexión fue exitosa
    if (!$connection) {
        die("Error al conectar a la base de datos: " . mysqli_connect_error());
    }

    // Create Movie
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_movie'])) {
        $title = $_POST['title'];
        $year = $_POST['year'];
        $cover = $_POST['cover'];
        $link = $_POST['link'];
        $producer = $_POST['producer'];
        $synopsis = $_POST['synopsis'];
        $mainCharacters = $_POST['main_characters'];
        $secondaryCharacters = $_POST['secondary_characters'];
        $category = $_POST['category'];

        // Insertar la nueva película en la tabla 'peliculas'
        $sql = "INSERT INTO peliculas (titulo, año, caratula, link, productora, sinopsis, personajes_principales, personajes_secundarios, categoria) 
                VALUES ('$title', '$year', '$cover', '$link', '$producer', '$synopsis', '$mainCharacters', '$secondaryCharacters', '$category')";

        if (mysqli_query($connection, $sql)) {
            echo '<p>Película creada exitosamente.</p>';
        } else {
            echo "Error al crear la película: " . mysqli_error($connection);
        }
    }

    // Edit Movie
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_movie'])) {
        $movieId = $_POST['movie_id'];
        $title = $_POST['title'];
        $year = $_POST['year'];
        $cover = $_POST['cover'];
        $link = $_POST['link'];
        $producer = $_POST['producer'];
        $synopsis = $_POST['synopsis'];
        $mainCharacters = $_POST['main_characters'];
        $secondaryCharacters = $_POST['secondary_characters'];
        $category = $_POST['category'];

        // Actualizar la película en la tabla 'peliculas'
        $sql = "UPDATE peliculas SET titulo='$title', año='$year', caratula='$cover', link='$link', productora='$producer', 
                sinopsis='$synopsis', personajes_principales='$mainCharacters', personajes_secundarios='$secondaryCharacters', 
                categoria='$category' WHERE id='$movieId'";

        if (mysqli_query($connection, $sql)) {
            echo '<p>Película editada exitosamente.</p>';
        } else {
            echo "Error al editar la película: " . mysqli_error($connection);
        }
    }

    // Delete Movie
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_movie'])) {
        $movieId = $_POST['movie_id'];

        // Eliminar la película de la tabla 'peliculas'
        $sql = "DELETE FROM peliculas WHERE id='$movieId'";

        if (mysqli_query($connection, $sql)) {
            echo '<p>Película eliminada exitosamente.</p>';
        } else {
            echo "Error al eliminar la película: " . mysqli_error($connection);
        }
    }
    ?>

    <!-- Create Movie Form -->
    <form action="crud.php" method="POST">
        <input type="text" name="title" placeholder="Title" required>
        <input type="number" name="year" placeholder="Year" required>
        <input type="text" name="cover" placeholder="Cover" required>
        <input type="text" name="link" placeholder="Link" required>
        <input type="text" name="producer" placeholder="Producer" required>
        <textarea name="synopsis" placeholder="Synopsis" required></textarea>
        <textarea name="main_characters" placeholder="Main Characters" required></textarea>
        <textarea name="secondary_characters" placeholder="Secondary Characters" required></textarea>
        <input type="text" name="category" placeholder="Category" required>
        <input type="submit" name="create_movie" value="Create Movie">
    </form>

    <!-- Edit Movie Form -->
    <form action="crud.php" method="POST">
        <?php
        // Obtener las películas existentes
        $sql = "SELECT id, titulo FROM peliculas";
        $result = mysqli_query($connection, $sql);
        $movies = mysqli_fetch_all($result, MYSQLI_ASSOC);

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_movie'])) {
            $movieId = $_POST['movie_id'];

            // Obtener los valores actuales de la película seleccionada
            $sql = "SELECT * FROM peliculas WHERE id='$movieId'";
            $result = mysqli_query($connection, $sql);
            $movie = mysqli_fetch_assoc($result);
        }
        ?>

        <select name="movie_id" required>
            <option value="">Selecciona una película</option>
            <?php foreach ($movies as $movie) : ?>
                <option value="<?php echo $movie['id']; ?>" <?php if (isset($movie['id']) && $movie['id'] === $movieId) echo 'selected'; ?>><?php echo $movie['titulo']; ?></option>
            <?php endforeach; ?>
        </select>
        <input type="text" name="title" placeholder="Title" value="<?php echo isset($movie['titulo']) ? $movie['titulo'] : ''; ?>" required>
        <input type="number" name="year" placeholder="Year" value="<?php echo isset($movie['año']) ? $movie['año'] : ''; ?>" required>
        <input type="text" name="cover" placeholder="Cover" value="<?php echo isset($movie['caratula']) ? $movie['caratula'] : ''; ?>" required>
        <input type="text" name="link" placeholder="Link" value="<?php echo isset($movie['link']) ? $movie['link'] : ''; ?>" required>
        <input type="text" name="producer" placeholder="Producer" value="<?php echo isset($movie['productora']) ? $movie['productora'] : ''; ?>" required>
        <textarea name="synopsis" placeholder="Synopsis" required><?php echo isset($movie['sinopsis']) ? $movie['sinopsis'] : ''; ?></textarea>
        <textarea name="main_characters" placeholder="Main Characters" required><?php echo isset($movie['personajes_principales']) ? $movie['personajes_principales'] : ''; ?></textarea>
        <textarea name="secondary_characters" placeholder="Secondary Characters" required><?php echo isset($movie['personajes_secundarios']) ? $movie['personajes_secundarios'] : ''; ?></textarea>
        <input type="text" name="category" placeholder="Category" required>
        <input type="submit" name="edit_movie" value="Edit Movie">
    </form>

    <!-- Delete Movie Form -->
    <form action="crud.php" method="POST">
        <select name="movie_id" required>
            <option value="">Selecciona una película</option>
            <?php foreach ($movies as $movie) : ?>
                <option value="<?php echo $movie['id']; ?>"><?php echo $movie['titulo']; ?></option>
            <?php endforeach; ?>
        </select>
        <input type="submit" name="delete_movie" value="Delete Movie">
    </form>

    <?php
    // Cerrar la conexión a la base de datos
    mysqli_close($connection);
    ?>

</body>

</html>
