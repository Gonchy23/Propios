<!DOCTYPE html>
<html>

<head>
    <title>Registro - Playdede</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        body {
            background-color: black;
            color: white;
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
            margin-top: 50px;
            font-size: 40px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 50px;
        }

        label {
            margin-bottom: 10px;
            font-size: 18px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 300px;
            padding: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 18px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <h1>Registro</h1>
    <?php
if (isset($_POST['submit'])) {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $dni = $_POST['dni'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['password'];

    $servername = "localhost";
    $username = "root";
    $password_db = "";
    $dbname = "usuarios";

    $conn = new mysqli($servername, $username, $password_db, $dbname);
    if ($conn->connect_error) {
        die("Error al conectar con la base de datos: " . $conn->connect_error);
    }

    // Hash de la contraseña utilizando bcrypt
    $contrasena_hash = password_hash($contrasena, PASSWORD_BCRYPT);

    // Utilizar consulta preparada para evitar inyección SQL
    $sql = "INSERT INTO usuarios (nombre, apellido, dni, correo, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $nombre, $apellido, $dni, $correo, $contrasena_hash);

    if ($stmt->execute()) {
        // Redireccionar a menu.php con el nombre de usuario en la URL
        header("Location: menu.php?usuario=$nombre");
        exit();
    } else {
        echo "Error al registrar el usuario: " . $conn->error;
    }
    $stmt->close();
    $conn->close();
}
?>


    <form method="POST" action="index.php">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required><br>

        <label for="apellido">Apellido:</label>
        <input type="text" name="apellido" required><br>

        <label for="dni">DNI:</label>
        <input type="text" name="dni" required><br>

        <label for="correo">Correo electrónico:</label>
        <input type="email" name="correo" required><br>

        <label for="password">Contraseña:</label>
        <input type="password" name="password" required><br>

        <input type="submit" name="submit" value="Registrarse">
    </form>
</body>

</html>
