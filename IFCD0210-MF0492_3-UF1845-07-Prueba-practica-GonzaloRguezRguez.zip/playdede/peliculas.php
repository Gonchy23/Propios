<!DOCTYPE html>
<html>

<head>
    <title>Playdede - Película</title>
    <link rel="shortcut icon" href="img/favicon32.png" type="image/x-icon">
    <style>
        body {
            background-color: black;
            color: white;
        }

        header {
            text-align: center;
            margin-bottom: 20px;
        }

        header h1 {
            font-size: 50px;
            margin: 0;
        }

        .pelicula-info {
            margin-top: 40px;
            margin-bottom: 60px;
        }

        .pelicula-info h2 {
            font-size: 24px;
            margin: 5px 0;
        }

        .pelicula-info p {
            font-size: 16px;
            margin: 0;
        }

        .personajes {
            margin-top: 40px;
        }

        .personaje {
            margin-bottom: 20px;
        }

        .personaje h3 {
            font-size: 18px;
            margin: 5px 0;
        }

        .personaje p {
            font-size: 14px;
            margin: 0;
        }

        .ver-pelicula {
            display: inline-block;
            padding: 10px 20px;
            background-color: #2ecc71;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .ver-pelicula:hover {
            background-color: #27ae60;
        }

        footer {
            text-align: center;
            margin-top: 40px;
        }
    </style>
</head>

<body>
    <header>
        <h1>Playdede</h1>
    </header>
    <div class="pelicula-container">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "playdede";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Error al conectar con la base de datos: " . $conn->connect_error);
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            $sql = "SELECT p.*, GROUP_CONCAT(d.nombre SEPARATOR ', ') AS directores FROM peliculas p LEFT JOIN peliculas_directores pd ON p.id = pd.pelicula_id LEFT JOIN directores d ON pd.director_id = d.id WHERE p.id = $id GROUP BY p.id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo '<div class="pelicula">';
                echo '<h2>' . $row['titulo'] . '</h2>';
                echo '<p>Directores: ' . $row['directores'] . '</p>';
                echo '<p>Año: ' . $row['año'] . '</p>';
                echo '<p>Categoría: ' . $row['categoria'] . '</p>';
                echo '<img src="' . $row['caratula'] . '">';
                echo '<p>' . $row['sinopsis'] . '</p>';
                echo '<h3>Personajes principales:</h3>';
                echo '<ul>';
                $personajesPrincipales = explode(',', $row['personajes_principales']);
                foreach ($personajesPrincipales as $personaje) {
                    echo '<li>' . $personaje . '</li>';
                }
                echo '</ul>';
                echo '<h3>Personajes secundarios:</h3>';
                echo '<ul>';
                $personajesSecundarios = explode(',', $row['personajes_secundarios']);
                foreach ($personajesSecundarios as $personaje) {
                    echo '<li>' . $personaje . '</li>';
                }
                echo '</ul>';
                echo '<a href="' . $row['link'] . '">Ver película</a>';
                echo '</div>';
            } else {
                echo '<p>No se encontró la película.</p>';
            }
        } else {
            echo '<p>No se proporcionó un ID de película.</p>';
        }
        $conn->close();
        ?>
    </div>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> Playdede. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
