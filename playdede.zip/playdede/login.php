<!DOCTYPE html>
<html>

<head>
    <title>Iniciar sesión - Playdede</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        body {
            background-color: black;
            color: white;
        }

        header {
            display: block;
            justify-content: space-between;
        }

        header h1 {
            text-align: center;
            margin: 0;
            font-size: 50px;
        }

        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            margin-right: 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
        }

        form {
            margin: 20px auto;
            max-width: 300px;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: blue;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: darkblue;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        .user-info {
            text-align: right;
        }

        .user-info span {
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <header>
        <h1>Playdede</h1>
    </header>

    <?php
    // Verificar si se ha enviado el formulario de inicio de sesión
    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        // Verificar si se seleccionó "Entrar como Invitado"
        if (isset($_POST["invitado"])) {
            // Redireccionar a index.php como Invitado
            header("Location: index.php?user=invitado");
            exit();
        } else {

            // Establecer la conexión con la base de datos
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "usuarios";

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Error al conectar con la base de datos: " . $conn->connect_error);
            }

            // Obtener los datos del formulario de inicio de sesión
            $nombre = $_POST['usuario']; // El campo del formulario es "usuario" pero representa el nombre del usuario
            $contrasena = $_POST['contrasena'];

            // Utilizar consulta preparada para evitar inyección SQL
            $sql = "SELECT * FROM usuarios WHERE nombre = ? LIMIT 1"; // Utilizar el campo "nombre" en lugar de "usuario"
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $nombre); // Vincular el parámetro con el nombre del usuario
            $stmt->execute();
            $result = $stmt->get_result();


            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $storedPassword = $row['password'];

                // Verificar la contraseña utilizando password_verify
                if (password_verify($contrasena, $storedPassword)) {
                    // Las credenciales son válidas, redireccionar a index.php como usuario registrado
                    header("Location: menu.php?usuario=$nombre");
                    exit();
                }
            }

            echo "Credenciales inválidas. Inténtalo de nuevo.";
            $stmt->close();
            $conn->close();
        }
    }
    ?>

    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <h2>Iniciar sesión</h2>

        <label for="usuario">Usuario:</label>
        <input type="text" name="usuario" required><br>

        <label for="contrasena">Contraseña:</label>
        <input type="password" name="contrasena" required><br>

        <input type="submit" value="Iniciar sesión">
    </form>

    <p>¿No quieres registrarte? <a href="invitado.php?user=invitado">Entrar como Invitado</a></p>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Playdede. Todos los derechos reservados.</p>
    </footer>
</body>

</html>