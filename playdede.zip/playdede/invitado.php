<!DOCTYPE html>
<html>

<head>
    <title>Playdede - Invitado</title>
    <link rel="shortcut icon" href="img/favicon32.png" type="image/x-icon">
    <style>
        body {
            background-color: black;
            color: white;
        }

        header {
            display: block;
            justify-content: space-between;
        }

        header h1 {
            text-align: center;
            margin: 0;
            font-size: 50px;
        }

        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
            margin-top: 10px;
        }

        nav ul li {
            margin-right: 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
        }

        .peliculas-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 40px;
            margin-bottom: 60px;
        }

        .pelicula {
            margin-right: 10px;
            width: 200px;
        }

        .pelicula img {
            width: 100%;
            height: auto;
            cursor: pointer;
        }

        .pelicula h2 {
            font-size: 16px;
            margin: 5px 0;
        }

        .pelicula p {
            font-size: 14px;
            margin: 0;
        }

        footer{
            margin-top: 140px;
        }
    </style>
</head>

<body>
    <header>
        <h1>Playdede - Invitado</h1>
        <nav>
            <ul>
                <li><a href="index.php?registrarse">Registrarse</a></li>
                <li><a href="login.php">Entrar como Usuario</a></li>
            </ul>
        </nav>
    </header>

    <div class="peliculas-container">
        <!-- Obtener datos de la base de datos -->
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "playdede";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Error al conectar con la base de datos: " . $conn->connect_error);
        }

        $sql = "SELECT p.*, d.nombre AS director_nombre FROM peliculas p LEFT JOIN peliculas_directores pd ON p.id = pd.pelicula_id LEFT JOIN directores d ON pd.director_id = d.id LIMIT 1";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            echo '<div class="pelicula">';
            echo '<a href="' . $row['link'] . '">';
            echo '<img src="' . $row['caratula'] . '">';
            echo '</a>';
            echo '<h2>' . $row['titulo'] . '</h2>';
            echo '<p>Año: ' . $row['año'] . '</p>';
            echo '<p>Director: ' . $row['director_nombre'] . '</p>';
            echo '<p>Categoría: ' . $row['categoria'] . '</p>';
            echo '</div>';
        } else {
            echo '<p>No hay películas disponibles.</p>';
        }
        $conn->close();
        ?>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Playdede. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
