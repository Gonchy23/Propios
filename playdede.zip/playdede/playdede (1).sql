-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-07-2023 a las 19:28:37
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `playdede`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `directores`
--

CREATE TABLE `directores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `directores`
--

INSERT INTO `directores` (`id`, `nombre`, `fecha_nacimiento`) VALUES
(1, 'Andrew Adamson', '1958-11-11'),
(2, 'Kelly Asbury', '1960-01-15'),
(3, 'Conrad Vernon', '1968-07-11'),
(4, 'Chris Miller', '1965-11-24'),
(5, 'Vicky Jenson', '1966-02-08'),
(6, 'Raman Hui', '1963-01-01'),
(7, 'Chad Stahelski', '1968-09-20'),
(8, 'James Cameron', '1954-08-16'),
(9, 'Lana Wachowski', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `peliculas`
--

CREATE TABLE `peliculas` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `año` int(11) DEFAULT NULL,
  `categoria` varchar(255) DEFAULT NULL,
  `caratula` varchar(100) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `productora` varchar(255) DEFAULT NULL,
  `sinopsis` text DEFAULT NULL,
  `personajes_principales` varchar(500) DEFAULT NULL,
  `personajes_secundarios` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `peliculas`
--

INSERT INTO `peliculas` (`id`, `titulo`, `año`, `categoria`, `caratula`, `link`, `productora`, `sinopsis`, `personajes_principales`, `personajes_secundarios`) VALUES
(1, 'Shrek 1', 2001, 'Animación, Comedia', 'http://localhost/playdede/img/shrek.jpg', 'https://gamovideo.net/i0m24l8m8uph', 'DreamWorks Animation', 'Shrek, un ogro verde, es enviado a rescatar a una princesa encerrada en una torre, pero termina enamorándose de ella.', 'Shrek (Mike Myers, 25 de mayo de 1963), Donkey (Eddie Murphy, 3 de abril de 1961), Fiona (Cameron Diaz, 30 de agosto de 1972)', 'Lord Farquaad (John Lithgow, 19 de octubre de 1945), Gingy (Conrad Vernon, 11 de julio de 1968), Pinocchio (Cody Cameron, 13 de octubre de 1970)'),
(2, 'Shrek 2', 2004, 'Animación', 'http://localhost/playdede/img/shrek2.jpg', 'https://gamovideo.com/bsfeybr7kd9h', 'DreamWorks Animation', 'Shrek y Fiona visitan a los padres de ella, pero las cosas se complican cuando Fiona recibe una invitación para una cena con su príncipe encantador.', 'Shrek (Mike Myers, 25 de mayo de 1963), Donkey (Eddie Murphy, 3 de abril de 1961), Puss in Boots (Antonio Banderas, 10 de agosto de 1960)', 'Fairy Godmother (Jennifer Saunders, 6 de julio de 1958), Prince Charming (Rupert Everett, 29 de mayo de 1959), Dragon (Frank Welker, 16 de marzo de 1946)'),
(3, 'Shrek 3', 2007, 'Animación', 'http://localhost/playdede/img/shrek3.jpg', 'https://gamovideo.com/rs0fslge97du', 'DreamWorks Animation', 'Shrek debe enfrentar su responsabilidad como rey tras la muerte del rey Harold, mientras busca un heredero legítimo para el trono.', 'Shrek (Mike Myers, 25 de mayo de 1963), Donkey (Eddie Murphy, 3 de abril de 1961), Fiona (Cameron Diaz, 30 de agosto de 1972)', 'Puss in Boots (Antonio Banderas, 10 de agosto de 1960), King Harold (John Cleese, 27 de octubre de 1939), Queen Lillian (Julie Andrews, 1 de octubre de 1935)'),
(4, 'John Wick 4', 2023, 'Acción', 'http://localhost/playdede/img/JhonWick4.jpg', 'https://gamovideo.net/25dtm0crtot6', 'Lionsgate', 'John Wick, un legendario asesino a sueldo, se ve envuelto en una nueva serie de peligrosas situaciones cuando un antiguo socio intenta tomar el control de una organización secreta de asesinos.', 'John Wick (Keanu Reeves, 2 de septiembre de 1964)', 'Charon (Lance Reddick, 31 de diciembre de 1962), Winston (Ian McShane, 29 de septiembre de 1942), Sofia (Halle Berry, 14 de agosto de 1966)'),
(5, 'Titanic', 1997, 'Drama', 'http://localhost/playdede/img/titanic.jpg', 'https://gamovideo.net/wdf4plaspgqz', '20th Century Fox', 'Una joven de clase alta se enamora de un pasajero de tercera clase en el trágico viaje inaugural del transatlántico Titanic.', 'Jack Dawson (Leonardo DiCaprio, 11 de noviembre de 1974), Rose DeWitt Bukater (Kate Winslet, 5 de octubre de 1975)', 'Cal Hockley (Billy Zane, 24 de febrero de 1966), Ruth DeWitt Bukater (Frances Fisher, 11 de mayo de 1952), Molly Brown (Kathy Bates, 28 de junio de 1948)'),
(7, 'The Matrix', 1999, 'Acción', 'https://example.com/the-matrix.jpg', 'https://example.com/the-matrix', 'Warner Bros', 'Thomas Anderson, un programador de software, descubre un mundo oculto lleno de realidades simuladas controladas por máquinas inteligentes. Junto con un grupo de rebeldes, lucha para liberar a la humanidad de la ilusión virtual conocida como la Matriz.', 'Neo, Trinity, Morpheus', 'Agent Smith, Cypher, Oracle');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `peliculas_directores`
--

CREATE TABLE `peliculas_directores` (
  `pelicula_id` int(11) DEFAULT NULL,
  `director_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `peliculas_directores`
--

INSERT INTO `peliculas_directores` (`pelicula_id`, `director_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 3),
(4, 7),
(3, 4),
(3, 6),
(5, 8);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `directores`
--
ALTER TABLE `directores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `peliculas`
--
ALTER TABLE `peliculas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `peliculas_directores`
--
ALTER TABLE `peliculas_directores`
  ADD KEY `pelicula_id` (`pelicula_id`),
  ADD KEY `director_id` (`director_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `directores`
--
ALTER TABLE `directores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `peliculas`
--
ALTER TABLE `peliculas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `peliculas_directores`
--
ALTER TABLE `peliculas_directores`
  ADD CONSTRAINT `peliculas_directores_ibfk_1` FOREIGN KEY (`pelicula_id`) REFERENCES `peliculas` (`id`),
  ADD CONSTRAINT `peliculas_directores_ibfk_2` FOREIGN KEY (`director_id`) REFERENCES `directores` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
