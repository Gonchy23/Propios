<!DOCTYPE html>
<html>

<head>
    <title>Playdede - Menú</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="shortcut icon" href="img/favicon32.png" type="image/x-icon">
    <style>
        body {
            background-color: black;
            color: white;
        }

        header {
            text-align: center;
            margin-bottom: 20px;
        }

        header h1 {
            font-size: 50px;
            margin: 0;
        }

        nav {
            text-align: center;
        }

        nav ul {
            list-style: none;
            display: inline-block;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 10px;
        }

        nav ul li a {
            text-decoration: none;
            color: white;
        }

        .submenu {
            display: none;
            position: absolute;
            background-color: black;
            padding: 10px;
            z-index: 1;
        }

        .submenu ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .submenu ul li {
            margin-bottom: 5px;
        }

        .submenu ul li a {
            color: white;
        }

        .peliculas-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 40px;
            margin-bottom: 60px;
        }

        .pelicula {
            margin-right: 10px;
            margin-bottom: 20px;
            width: 200px;
        }

        .pelicula img {
            width: 100%;
            height: auto;
            cursor: pointer;
        }

        .pelicula h2 {
            font-size: 16px;
            margin: 5px 0;
        }

        .pelicula p {
            font-size: 14px;
            margin: 0;
        }
    </style>
</head>

<body>
    <header>
        <h1>Playdede</h1>
    </header>

    <nav>
        <ul>
            <li><a href="invitado.php">Entrar como invitado</a></li>
            <li><a href="login.php">Cerrar Sesión</a></li>
            <li>
                <a href="#" onclick="toggleSubmenu('categorias')">Categorías</a>
                <div id="categoriasSubmenu" class="submenu">
                    <ul>
                        <li><a href="menu.php">Todas</a></li>
                        <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "playdede";

                        $conn = new mysqli($servername, $username, $password, $dbname);
                        if ($conn->connect_error) {
                            die("Error al conectar con la base de datos: " . $conn->connect_error);
                        }

                        $sql = "SELECT DISTINCT categoria FROM peliculas";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<li><a href="menu.php?categoria=' . $row['categoria'] . '">' . $row['categoria'] . '</a></li>';
                            }
                        }
                        $conn->close();
                        ?>
                    </ul>
                </div>
            </li>
            <li>
                <a href="#" onclick="toggleSubmenu('directores')">Buscar por Director</a>
                <div id="directoresSubmenu" class="submenu">
                    <form action="menu.php" method="GET">
                        <select name="director">
                            <option value="">Todos</option>
                            <?php
                            $conn = new mysqli($servername, $username, $password, $dbname);
                            if ($conn->connect_error) {
                                die("Error al conectar con la base de datos: " . $conn->connect_error);
                            }

                            $sql = "SELECT * FROM directores";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo '<option value="' . $row['nombre'] . '">' . $row['nombre'] . '</option>';
                                }
                            }
                            $conn->close();
                            ?>
                        </select>
                        <input type="submit" value="Buscar">
                    </form>
                </div>
            </li>
            <li>
            <a href="#" onclick="toggleSubmenu('crud')">CRUD</a>
            <div id="crudSubmenu" class="submenu">
                <ul>
                    <li><a href="crud.php">Crear Película</a></li>
                    <li><a href="crud.php">Borrar Película</a></li>
                    <li><a href="crud.php">Editar Película</a></li>
                </ul>
            </div>
            </li>
        </ul>
    </nav>
    <div class="peliculas-container">
        <?php
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Error al conectar con la base de datos: " . $conn->connect_error);
        }

        if (isset($_GET['categoria'])) {
            $categoria = $_GET['categoria'];
            $sql = "SELECT p.*, GROUP_CONCAT(d.nombre SEPARATOR ', ') AS directores FROM peliculas p LEFT JOIN peliculas_directores pd ON p.id = pd.pelicula_id LEFT JOIN directores d ON pd.director_id = d.id WHERE p.categoria = '$categoria' GROUP BY p.id";
        } else if (isset($_GET['director'])) {
            $director = $_GET['director'];
            if ($director === "") {
                $sql = "SELECT p.*, GROUP_CONCAT(d.nombre SEPARATOR ', ') AS directores FROM peliculas p LEFT JOIN peliculas_directores pd ON p.id = pd.pelicula_id LEFT JOIN directores d ON pd.director_id = d.id GROUP BY p.id";
            } else {
                $sql = "SELECT p.*, GROUP_CONCAT(d.nombre SEPARATOR ', ') AS directores FROM peliculas p LEFT JOIN peliculas_directores pd ON p.id = pd.pelicula_id LEFT JOIN directores d ON pd.director_id = d.id WHERE d.nombre = '$director' GROUP BY p.id";
            }
        } else {
            $sql = "SELECT p.*, GROUP_CONCAT(d.nombre SEPARATOR ', ') AS directores FROM peliculas p LEFT JOIN peliculas_directores pd ON p.id = pd.pelicula_id LEFT JOIN directores d ON pd.director_id = d.id GROUP BY p.id";
        }

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="pelicula">';
                echo '<a href="peliculas.php?id=' . $row['id'] . '">';
                echo '<img src="' . $row['caratula'] . '">';
                echo '</a>';
                echo '<h2>' . $row['titulo'] . '</h2>';
                echo '<p>Directores: ' . $row['directores'] . '</p>';
                echo '<p>Año: ' . $row['año'] . '</p>';
                echo '<p>Categoría: ' . $row['categoria'] . '</p>';
                echo '</div>';
            }
        } else {
            echo '<p>No hay películas disponibles.</p>';
        }
        $conn->close();
        ?>
    </div>

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Playdede. Todos los derechos reservados.</p>
    </footer>

    <script>
        function toggleSubmenu(submenuId) {
            var submenu = document.getElementById(submenuId + 'Submenu');
            if (submenu.style.display === 'none') {
                submenu.style.display = 'block';
            } else {
                submenu.style.display = 'none';
            }
        }
    </script>
</body>

</html>
